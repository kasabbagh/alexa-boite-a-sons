"""
Alexa Skill - Boîte à Sons
Joue des sons d'animaux, transports, nature, etc.
"""

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Mapping des mots-clés français vers les sons ASK Sound Library
SOUNDS = {
    # Animaux
    "ours": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_bear_groan_roar_01"/>',
    "oiseau": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_bird_forest_01"/>',
    "chat": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_cat_meow_1x_01"/>',
    "chaton": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_cat_purr_01"/>',
    "poulet": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_chicken_cluck_01"/>',
    "poule": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_chicken_cluck_01"/>',
    "corbeau": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_crow_caw_1x_01"/>',
    "chien": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_dog_med_bark_1x_02"/>',
    "éléphant": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_elephant_01"/>',
    "elephant": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_elephant_01"/>',
    "cheval": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_horse_neigh_01"/>',
    "galop": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_horse_gallop_4x_01"/>',
    "lion": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_lion_roar_01"/>',
    "singe": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_monkey_chimp_01"/>',
    "rat": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_rat_squeaks_01"/>',
    "souris": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_rat_squeaks_01"/>',
    "coq": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_rooster_crow_01"/>',
    "mouton": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_sheep_baa_01"/>',
    "dinde": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_turkey_gobbling_01"/>',
    "loup": '<audio src="soundbank://soundlibrary/animals/amzn_sfx_wolf_howl_01"/>',
    # Transports
    "avion": '<audio src="soundbank://soundlibrary/transportation/amzn_sfx_airplane_takeoff_whoosh_01"/>',
    "vélo": '<audio src="soundbank://soundlibrary/transportation/amzn_sfx_bicycle_bell_ring_01"/>',
    "velo": '<audio src="soundbank://soundlibrary/transportation/amzn_sfx_bicycle_bell_ring_01"/>',
    "bus": '<audio src="soundbank://soundlibrary/transportation/amzn_sfx_bus_drive_past_01"/>',
    "voiture": '<audio src="soundbank://soundlibrary/transportation/amzn_sfx_car_accelerate_01"/>',
    "klaxon": '<audio src="soundbank://soundlibrary/transportation/amzn_sfx_car_honk_1x_01"/>',
    "moto": '<audio src="soundbank://soundlibrary/transportation/amzn_sfx_motorcycle_engine_rev_01"/>',
    "métro": '<audio src="soundbank://soundlibrary/transportation/amzn_sfx_subway_passing_01"/>',
    "metro": '<audio src="soundbank://soundlibrary/transportation/amzn_sfx_subway_passing_01"/>',
    # Nature
    "tremblement de terre": '<audio src="soundbank://soundlibrary/nature/amzn_sfx_earthquake_rumble_01"/>',
    "éclair": '<audio src="soundbank://soundlibrary/nature/amzn_sfx_lightning_strike_01"/>',
    "océan": '<audio src="soundbank://soundlibrary/nature/amzn_sfx_ocean_wave_1x_01"/>',
    "ocean": '<audio src="soundbank://soundlibrary/nature/amzn_sfx_ocean_wave_1x_01"/>',
    "vague": '<audio src="soundbank://soundlibrary/nature/amzn_sfx_ocean_wave_on_rocks_1x_01"/>',
    "pluie": '<audio src="soundbank://soundlibrary/nature/amzn_sfx_rain_01"/>',
    "orage": '<audio src="soundbank://soundlibrary/nature/amzn_sfx_rain_thunder_01"/>',
    "tonnerre": '<audio src="soundbank://soundlibrary/nature/amzn_sfx_thunder_rumble_01"/>',
    "rivière": '<audio src="soundbank://soundlibrary/nature/amzn_sfx_stream_01"/>',
    "riviere": '<audio src="soundbank://soundlibrary/nature/amzn_sfx_stream_01"/>',
    "vent": '<audio src="soundbank://soundlibrary/nature/amzn_sfx_strong_wind_whistling_01"/>',
    # Maison
    "porte": '<audio src="soundbank://soundlibrary/home/amzn_sfx_door_open_01"/>',
    "sonnette": '<audio src="soundbank://soundlibrary/home/amzn_sfx_doorbell_chime_01"/>',
    "cheminée": '<audio src="soundbank://soundlibrary/home/amzn_sfx_fireplace_crackle_01"/>',
    "cheminee": '<audio src="soundbank://soundlibrary/home/amzn_sfx_fireplace_crackle_01"/>',
    "aspirateur": '<audio src="soundbank://soundlibrary/home/amzn_sfx_vacuum_on_01"/>',
    # Humains
    "bébé": '<audio src="soundbank://soundlibrary/human/amzn_sfx_baby_big_cry_01"/>',
    "bebe": '<audio src="soundbank://soundlibrary/human/amzn_sfx_baby_big_cry_01"/>',
    "applaudissements": '<audio src="soundbank://soundlibrary/human/amzn_sfx_crowd_applause_01"/>',
    "bravo": '<audio src="soundbank://soundlibrary/human/amzn_sfx_crowd_applause_01"/>',
    "huées": '<audio src="soundbank://soundlibrary/human/amzn_sfx_crowd_boo_01"/>',
    "rire": '<audio src="soundbank://soundlibrary/human/amzn_sfx_laughter_01"/>',
    "toux": '<audio src="soundbank://soundlibrary/human/amzn_sfx_cough_01"/>',
    "éternuement": '<audio src="soundbank://soundlibrary/human/amzn_sfx_sneeze_01"/>',
    # Divers
    "feux d'artifice": '<audio src="soundbank://soundlibrary/impacts/amzn_sfx_fireworks_01"/>',
    "fantôme": '<audio src="soundbank://soundlibrary/magic/amzn_sfx_ghost_spooky_01"/>',
    "fantome": '<audio src="soundbank://soundlibrary/magic/amzn_sfx_ghost_spooky_01"/>',
    "trompette": '<audio src="soundbank://soundlibrary/musical/amzn_sfx_trumpet_bugle_01"/>',
    "tambour": '<audio src="soundbank://soundlibrary/musical/amzn_sfx_drum_comedy_01"/>',
    "guitare": '<audio src="soundbank://soundlibrary/musical/amzn_sfx_electric_guitar_01"/>',
}


def build_response(speech, should_end_session=False, reprompt=None):
    """Construit la réponse JSON pour Alexa."""
    response = {
        "version": "1.0",
        "response": {
            "outputSpeech": {
                "type": "SSML",
                "ssml": f"<speak>{speech}</speak>",
            },
            "shouldEndSession": should_end_session,
        },
    }
    if reprompt:
        response["response"]["reprompt"] = {
            "outputSpeech": {
                "type": "SSML",
                "ssml": f"<speak>{reprompt}</speak>",
            }
        }
    return response


def handle_launch(event):
    """Quand l'utilisateur dit 'Alexa, ouvre Boîte à Sons'."""
    speech = "Boîte à sons ouverte ! Dis le nom d'un animal ou d'un son. Par exemple : cheval, voiture, ou lion."
    reprompt = "Quel son veux-tu entendre ?"
    return build_response(speech, should_end_session=False, reprompt=reprompt)


def handle_sound_intent(event):
    """Quand l'utilisateur demande un son."""
    try:
        slots = event["request"]["intent"]["slots"]
        sound_name = slots["son"]["value"].lower().strip()
    except (KeyError, TypeError):
        speech = "Je n'ai pas compris. Dis le nom d'un animal ou d'un véhicule."
        return build_response(speech, should_end_session=False, reprompt="Quel son veux-tu ?")

    if sound_name in SOUNDS:
        audio = SOUNDS[sound_name]
        speech = f"{audio}"
        reprompt = "Quel autre son veux-tu ?"
        return build_response(speech, should_end_session=False, reprompt=reprompt)
    else:
        speech = f"Je ne connais pas le son {sound_name}. Essaie cheval, chat, voiture ou lion."
        reprompt = "Quel son veux-tu ?"
        return build_response(speech, should_end_session=False, reprompt=reprompt)


def handle_help(event):
    """Intent d'aide."""
    speech = (
        "Tu peux me demander n'importe quel son. "
        "Par exemple dis : cheval, chien, voiture, lion, pluie, ou tonnerre. "
        "Quel son veux-tu entendre ?"
    )
    return build_response(speech, should_end_session=False, reprompt="Quel son veux-tu ?")


def handle_stop(event):
    """Quand l'utilisateur dit stop ou annuler."""
    speech = "À bientôt !"
    return build_response(speech, should_end_session=True)


def lambda_handler(event, context):
    """Point d'entrée Lambda."""
    logger.info(f"Event: {event}")

    request_type = event["request"]["type"]

    if request_type == "LaunchRequest":
        return handle_launch(event)

    elif request_type == "IntentRequest":
        intent_name = event["request"]["intent"]["name"]

        if intent_name == "PlaySoundIntent":
            return handle_sound_intent(event)
        elif intent_name == "AMAZON.HelpIntent":
            return handle_help(event)
        elif intent_name in ("AMAZON.StopIntent", "AMAZON.CancelIntent"):
            return handle_stop(event)
        elif intent_name == "AMAZON.FallbackIntent":
            speech = "Je n'ai pas compris. Dis le nom d'un animal ou d'un son."
            return build_response(speech, should_end_session=False, reprompt="Quel son veux-tu ?")
        else:
            return handle_sound_intent(event)

    elif request_type == "SessionEndedRequest":
        return build_response("", should_end_session=True)

    return build_response("Une erreur est survenue.", should_end_session=True)
